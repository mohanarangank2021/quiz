import { Component, OnInit } from '@angular/core';

import { fuseAnimations } from '@fuse/animations';
// import { NgxTextEditorModule } from 'ngx-text-editor';

// const material = [
//   NgxTextEditorModule
// ]

interface Action {
  value: string;
  viewValue: string;
}
interface Product {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-edit-topic',
  templateUrl: './edit-topic.component.html',
  styleUrls: ['./edit-topic.component.scss'],
  animations   : fuseAnimations,
})


export class EditTopicComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  actions : Action[] = [
    {value: 'active', viewValue: 'Active'},
    {value: 'inactive', viewValue: 'Inactive'},
    {value: 'deleted', viewValue: 'Deleted'}
  ];

  products : Product[] = [
    {value: 'topic1', viewValue: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'},
    {value: 'topic2', viewValue: 'Muffin sugar plum icing pudding.'},
    {value: 'topic3', viewValue: 'Bear claw carrot cake jelly halvah carrot cake.'},
    {value: 'topic4', viewValue: 'Chupa chups muffin chocolate bar jujubes.'},
    {value: 'topic5', viewValue: 'lemon drops lemon drops macaroon oat cake pudding.'},
    {value: 'topic6', viewValue: 'Bonbon lemon drops candy caramels.'},
  ];
  showAction : boolean = false;
  shownoPreview : boolean = true;
  clickEvent(){
    this.showAction = !this.showAction;      
    this.shownoPreview = !this.shownoPreview;      
  }

}
