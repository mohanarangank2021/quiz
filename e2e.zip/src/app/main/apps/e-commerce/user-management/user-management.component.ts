import { Component, OnInit } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';

export interface PeriodicElement {
  name: string;
  position: string;
  weight: string;
  symbol: string;
  imageUrl: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 'USER7866876', name: 'Abbot Keitch', weight: 'abbott@withinpixels.com', symbol: 'Active', imageUrl:'assets/images/avatars/Abbott.jpg'},
  {position: 'USER7866876', name: 'Arnold Matlock', weight: 'abbott@withinpixels.com', symbol: 'Banned', imageUrl:'assets/images/avatars/alice.jpg'},
  {position: 'USER7866876', name: 'Barrera Bradbury', weight: 'abbott@withinpixels.com', symbol: 'Inactive', imageUrl:'assets/images/avatars/andrew.jpg'},
  {position: 'USER7866876', name: 'Christy Camacho', weight: 'abbott@withinpixels.com', symbol: 'Active', imageUrl:'assets/images/avatars/Arnold.jpg'},
  {position: 'USER7866876', name: 'Copeland Redcliff', weight: 'abbott@withinpixels.com', symbol: 'Inactive', imageUrl:'assets/images/avatars/Blair.jpg'},
  {position: 'USER7866876', name: 'Estes Stevens', weight: 'abbott@withinpixels.com', symbol: 'Banned', imageUrl:'assets/images/avatars/carl.jpg'},
  {position: 'USER7866876', name: 'Helen Sheridan', weight: 'abbott@withinpixels.com', symbol: 'Active', imageUrl:'assets/images/avatars/Copeland.jpg'},
  {position: 'USER7866876', name: 'Harper MacGuffin', weight: 'abbott@withinpixels.com', symbol: 'Active', imageUrl:'assets/images/avatars/Estes.jpg'},
  {position: 'USER7866876', name: 'Odessa Goodman', weight: 'abbott@withinpixels.com', symbol: 'Inactive', imageUrl:'assets/images/avatars/garry.jpg'},
  {position: 'USER7866876', name: 'Reyna Preece', weight: 'abbott@withinpixels.com', symbol: 'Banned', imageUrl:'assets/images/avatars/Harper.jpg'},
  {position: 'USER7866876', name: 'Reyna Preece', weight: 'abbott@withinpixels.com', symbol: 'Banned', imageUrl:'assets/images/avatars/Harper.jpg'},
  {position: 'USER7866876', name: 'Reyna Preece', weight: 'abbott@withinpixels.com', symbol: 'Banned', imageUrl:'assets/images/avatars/Harper.jpg'},
  {position: 'USER7866876', name: 'Reyna Preece', weight: 'abbott@withinpixels.com', symbol: 'Banned', imageUrl:'assets/images/avatars/Harper.jpg'},
];


interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.scss'],
  animations   : fuseAnimations
})
export class UserManagementComponent implements OnInit {

  displayedColumns: string[] = [ 'imageUrl','position', 'name', 'weight', 'symbol',];
  dataSource = ELEMENT_DATA;

  showAction : boolean = true;
  // showAction1 : boolean = false;
  classToggled : boolean = false;
  clickEvent(){
    this.showAction = !this.showAction;  
    this.classToggled = !this.classToggled;     
  }

  foods: Food[] = [
    {value: 'activate', viewValue: 'Activate'},
    {value: 'ban', viewValue: 'Ban'},
    {value: 'delete', viewValue: 'Delete'}
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
