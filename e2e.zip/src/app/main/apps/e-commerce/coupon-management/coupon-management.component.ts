import { Component, OnInit } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { fuseAnimations } from '@fuse/animations';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { FormGroup, FormControl } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';

import { DataSource } from '@angular/cdk/collections';

const material = [
  MatTableModule,
  MatCheckboxModule,
  FuseConfirmDialogComponent,
  DataSource,
  MatDatepickerModule,
  MatInputModule,
  MatNativeDateModule,
  FormGroup,
  FormControl,
  MatButtonModule
  
]

export interface PeriodicElement {
  code: string;
  id: number;
  amount: number;
  minpurchase: number;
  startDate: string;
  endDate: string;
  usageCount: number;
  maxLimit: number;
  maxLimitPerson: number;
  status: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {id: 1, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 2, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Live'},
  {id: 3, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Deleted'},
  {id: 4, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Deleted'},
  {id: 5, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Live'},
  {id: 6, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 7, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Deleted'},
  {id: 8, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Live'},
  {id: 9, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Live'},
  {id: 10, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 11, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 12, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 13, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 14, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 15, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 16, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 17, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 18, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 19, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 20, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 21, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 22, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 23, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 24, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 25, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 26, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 27, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
  {id: 28, code: 'CHRIST45862', amount: 5652, minpurchase: 3565, startDate: '14/12/2018', endDate: '05/02/2019', usageCount: 3565, maxLimit: 3565, maxLimitPerson: 3565, status: 'Expired'},
];


  interface Food {
    value: string;
    viewValue: string;
  }
  interface Type {
    value: string;
    viewValue: string;
  }

@Component({
  selector: 'app-coupon-management',
  templateUrl: './coupon-management.component.html',
  styleUrls: ['./coupon-management.component.scss'],
  animations   : fuseAnimations
})

// const material = [
//   MatTableModule
// ]


export class CouponManagementComponent implements OnInit {


  

  constructor() { }

  ngOnInit(): void {
  }

  displayedColumns: string[] = ['id', 'code', 'amount', 'minpurchase', 'startDate', 'endDate', 'usageCount', 'maxLimit', 'maxLimitPerson', 'status'];
  dataSource = ELEMENT_DATA;

  checked = false;
  indeterminate = false;
  labelPosition: 'before' | 'after' = 'after';
  disabled = false;


  showAction : boolean = true;
  showAction1 : boolean = false;
  classToggled : boolean = false;
  clickEvent(){
    this.showAction = !this.showAction;  
    this.classToggled = !this.classToggled;     
  }


  foods: Food[] = [
    {value: 'expired', viewValue: 'Expired'},
    {value: 'live', viewValue: 'Live'},
    {value: 'deleted', viewValue: 'Deleted'}
  ];

  types: Type[] = [
    {value: 'type1', viewValue: 'Type 1'},
    {value: 'type2', viewValue: 'Type 2'},
    {value: 'type3', viewValue: 'Type 3'}
  ]

}
// @NgModule({
//   imports: [
//     MatTableModule
//   ]
// })





