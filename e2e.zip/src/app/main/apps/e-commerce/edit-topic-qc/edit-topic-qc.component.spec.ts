import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditTopicQcComponent } from './edit-topic-qc.component';

describe('EditTopicQcComponent', () => {
  let component: EditTopicQcComponent;
  let fixture: ComponentFixture<EditTopicQcComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditTopicQcComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditTopicQcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
