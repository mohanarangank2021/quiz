import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { GenerateReportComponent } from './generate-report/generate-report.component';

const material = [
  MatDialog,
  MatDialogRef,
]

@Component({
  selector: 'app-edit-topic-qc',
  templateUrl: './edit-topic-qc.component.html',
  styleUrls: ['./edit-topic-qc.component.scss'],
  providers: [{ provide: MatDialog, useValue: {} }]
})


export class EditTopicQcComponent implements OnInit {
  animal: string;
  name: string;
  constructor(public dialog: MatDialog) {}

  ngOnInit(): void {
  }

  openDialog() {
    const dialogRef = this.dialog.open(GenerateReportComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }
  

}


