import { Component, OnInit } from '@angular/core';

export interface PeriodicElement {
  name: string;
  position: string;
  weight: string;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 'USER7866876', name: 'Abbot Keitch', weight: 'abbott@withinpixels.com', symbol: 'Admin'},
  {position: 'USER7866876', name: 'Arnold Matlock', weight: 'abbott@withinpixels.com', symbol: 'Student'},
  {position: 'USER7866876', name: 'Barrera Bradbury', weight: 'abbott@withinpixels.com', symbol: 'Admin'},
  {position: 'USER7866876', name: 'Christy Camacho', weight: 'abbott@withinpixels.com', symbol: 'Student'},
  {position: 'USER7866876', name: 'Copeland Redcliff', weight: 'abbott@withinpixels.com', symbol: 'Admin'},
  {position: 'USER7866876', name: 'Estes Stevens', weight: 'abbott@withinpixels.com', symbol: 'Admin'},
  {position: 'USER7866876', name: 'Helen Sheridan', weight: 'abbott@withinpixels.com', symbol: 'Student'},
  {position: 'USER7866876', name: 'Harper MacGuffin', weight: 'abbott@withinpixels.com', symbol: 'Admin'},
  {position: 'USER7866876', name: 'Odessa Goodman', weight: 'abbott@withinpixels.com', symbol: 'Student'},
  {position: 'USER7866876', name: 'Reyna Preece', weight: 'abbott@withinpixels.com', symbol: 'Admin'},
];


@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.scss']
})
export class UserManagementComponent implements OnInit {

  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  dataSource = ELEMENT_DATA;

  showAction : boolean = true;
  // showAction1 : boolean = false;
  classToggled : boolean = false;
  clickEvent(){
    this.showAction = !this.showAction;  
    this.classToggled = !this.classToggled;     
  }

  constructor() { }

  ngOnInit(): void {
  }

}
